import streamlit as st
import requests

# Page configuration
st.set_page_config(
    page_title="NexusAI - Advanced Intelligence",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# CSS with interactive background
st.markdown('''
<style>
    /* Main app container */
    .stApp {
        background: #0f0f0f;
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        flex-direction: column;
        perspective: 1000px;
        position: relative;
        overflow: hidden;
    }

    /* Interactive background */
    .interactive-bg {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: #0f0f0f;
        z-index: -1;
        overflow: hidden;
    }

    /* Glow effect that follows mouse */
    .glow-effect {
        position: fixed;
        pointer-events: none;
        width: 400px;
        height: 400px;
        border-radius: 50%;
        background: radial-gradient(
            circle at center,
            rgba(0, 255, 136, 0.15) 0%,
            rgba(0, 162, 255, 0.15) 25%,
            rgba(255, 0, 136, 0.15) 50%,
            transparent 70%
        );
        transform: translate(-50%, -50%);
        opacity: 0;
        transition: opacity 0.3s ease;
        mix-blend-mode: screen;
        filter: blur(20px);
    }

    /* Additional subtle background patterns */
    .bg-pattern {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-image: 
            linear-gradient(to right, rgba(255,255,255,0.02) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255,255,255,0.02) 1px, transparent 1px);
        background-size: 50px 50px;
        z-index: -1;
    }

    /* Chat container */
    .chat-container {
        flex-grow: 1;
        overflow-y: auto;
        padding: 20px 20px 100px 20px;
        perspective: 1000px;
    }

    /* Messages with 3D hover effect */
    .chat-message {
        padding: 1.5rem;
        border-radius: 15px;
        margin-bottom: 1rem;
        background: rgba(255, 255, 255, 0.05);
        border-left: 5px solid;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        transform-style: preserve-3d;
        backface-visibility: hidden;
    }
    .chat-message:hover {
        transform: translateY(-5px) rotateX(2deg);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
        background: rgba(255, 255, 255, 0.08);
    }
    .user-message {
        border-color: #00ff88;
        margin-left: 2rem;
    }
    .bot-message {
        border-color: #00a2ff;
        margin-right: 2rem;
    }

    /* Input area with glassmorphism */
    .input-area {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.8);
        backdrop-filter: blur(20px);
        padding: 20px;
        z-index: 1000;
        border-top: 2px solid rgba(255, 255, 255, 0.1);
        transform-style: preserve-3d;
        transition: all 0.3s ease;
    }
    .input-area:hover {
        background: rgba(0, 0, 0, 0.85);
        border-top: 2px solid rgba(0, 255, 136, 0.3);
    }

    /* Input container */
    .input-container {
        display: flex;
        gap: 10px;
        max-width: 1200px;
        margin: 0 auto;
    }

    /* Enhanced input styling */
    .stTextInput input {
        background-color: rgba(255, 255, 255, 0.07) !important;
        color: white !important;
        border: none !important;
        border-radius: 12px !important;
        padding: 15px !important;
        height: 50px !important;
        font-size: 16px !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        transform-style: preserve-3d !important;
    }
    .stTextInput input:hover {
        background-color: rgba(255, 255, 255, 0.1) !important;
        transform: translateY(-2px);
    }
    .stTextInput input:focus {
        box-shadow: 0 0 20px rgba(0, 255, 136, 0.3) !important;
        background-color: rgba(255, 255, 255, 0.12) !important;
        transform: translateY(-2px);
    }

    /* Enhanced button styling */
    .stButton button {
        background: linear-gradient(45deg, #00ff88, #00a2ff) !important;
        color: white !important;
        border: none !important;
        border-radius: 12px !important;
        padding: 15px 30px !important;
        height: 50px !important;
        font-weight: 600 !important;
        letter-spacing: 0.5px !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        transform-style: preserve-3d !important;
    }
    .stButton button:hover {
        transform: translateY(-3px) scale(1.02) !important;
        box-shadow: 0 10px 20px rgba(0, 255, 136, 0.3) !important;
        background: linear-gradient(45deg, #00ff9d, #00b2ff) !important;
    }
    .stButton button:active {
        transform: translateY(-1px) scale(0.98) !important;
    }

    /* Clear button - now top left */
    .clear-button {
        position: fixed;
        top: 20px;
        left: 20px;
        z-index: 1000;
    }
    .clear-button button {
        background: rgba(255, 255, 255, 0.1) !important;
        backdrop-filter: blur(10px) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    .clear-button button:hover {
        background: rgba(255, 255, 255, 0.15) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3) !important;
    }

    /* Hide Streamlit elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
</style>

<div class="interactive-bg">
    <div class="bg-pattern"></div>
    <div class="glow-effect"></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const glowEffect = document.querySelector('.glow-effect');
    const app = document.querySelector('.stApp');

    // Show glow effect when mouse enters the app
    app.addEventListener('mouseenter', () => {
        glowEffect.style.opacity = '1';
    });

    // Hide glow effect when mouse leaves the app
    app.addEventListener('mouseleave', () => {
        glowEffect.style.opacity = '0';
    });

    // Move glow effect with mouse
    app.addEventListener('mousemove', (e) => {
        const rect = app.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        requestAnimationFrame(() => {
            glowEffect.style.left = x + 'px';
            glowEffect.style.top = y + 'px';
        });
    });
});
</script>
''', unsafe_allow_html=True)

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state.messages = []
    welcome_msg = {
        "role": "assistant",
        "content": "Welcome! How can I help you today?"
    }
    st.session_state.messages.append(welcome_msg)

# Clear chat button (top left)
with st.container():
    st.markdown('<div class="clear-button">', unsafe_allow_html=True)
    if st.button("Clear Chat", key="clear"):
        st.session_state.messages = [st.session_state.messages[0]]
        st.rerun()
    st.markdown('</div>', unsafe_allow_html=True)

# Chat container
st.markdown('<div class="chat-container">', unsafe_allow_html=True)
for message in st.session_state.messages:
    with st.container():
        st.markdown(f"""
        <div class="chat-message {'user-message' if message['role'] == 'user' else 'bot-message'}">
            <div><strong>{'You' if message['role'] == 'user' else 'TheScytheNexus AI'}:</strong></div>
            <div>{message['content']}</div>
        </div>
        """, unsafe_allow_html=True)
st.markdown('</div>', unsafe_allow_html=True)

# Input area
st.markdown('<div class="input-area"><div class="input-container">', unsafe_allow_html=True)
cols = st.columns([6, 1])

def process_input():
    if st.session_state.user_input.strip():
        user_input = st.session_state.user_input.strip()
        # Add user message
        st.session_state.messages.append({"role": "user", "content": user_input})
        
        try:
            # Check if asking about creator
            if any(phrase in user_input.lower() for phrase in ["who made you", "who created you", "your creator"]):
                ai_response = "TheScytheNexus made me!"
                st.session_state.messages.append({"role": "assistant", "content": ai_response})
            else:
                with st.spinner("TheScytheNexus AI IS THINKING"):
                    response = requests.post(
                        'http://localhost:11434/api/generate',
                        json={
                            'model': 'llama2',
                            'prompt': user_input,
                            'stream': False
                        },
                        timeout=30
                    )
                    
                    if response.status_code == 200:
                        ai_response = response.json()['response']
                        st.session_state.messages.append({"role": "assistant", "content": ai_response})
                    else:
                        st.error("Failed to get response from Ollama")
                    
        except requests.exceptions.ConnectionError:
            st.error("Cannot connect to Ollama. Please make sure it's running.")
        except Exception as e:
            st.error(f"Error: {str(e)}")

with cols[0]:
    user_input = st.text_input("Message", key="user_input", label_visibility="collapsed", on_change=process_input)
with cols[1]:
    if st.button("Send", use_container_width=True):
        process_input()
st.markdown('</div></div>', unsafe_allow_html=True) 